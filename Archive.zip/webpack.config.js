const Dotenv = require('dotenv-webpack');
const path = require('path');
console.log( path.resolve(__dirname, '.env'))


module.exports = {
  devtool: 'source-map',
  plugins: [
    new Dotenv({systemvars: true,
      path: path.resolve(__dirname, '.env')
    })
    ],
  module: {
    rules: [
      {
        test: /\.js$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        options: {
          presets: ['@babel/preset-react']
        }
      },
      {
        test: /\.css$/i,
        use: ["style-loader", "css-loader"],
      },
    ]
  }
};

