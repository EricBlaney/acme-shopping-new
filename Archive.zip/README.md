# acme-auth-ci

- create dev and testing databases
- npm i
- open second terminal, goto this directory and run cmd 'node cors' concurrently with npm run start:dev
- npm run test:dev
- npm run start:dev

BEFORE RUNNING APP, OPEN SECOND TERMINAL, GOTO THIS DIRECTORY AND RUN NODE CORS CONCURRENTLY WITH NPM RUN START:DEV

<!-- 
Payment update: 
1. payment page (left: credit card, right: order summary)
2. After payment page: Congratulations! Your order is completed! (Set a time count: You will be directed to the home page after 5 seconds)

Cart update: 
1. Added an icon for the cart, and also the small number on the icon showing how many items you added into the char
2. pop up notifications -->


<!-- //disabled account page
//all products should be viewable 
//added into cart -->
<!-- //after  -->



<!-- wishlist添加弹窗
Profile中的add to cart不work
Total price没有随商品变化增加或者减少
add to cart这个Button怎样在nav中的不通商品列表里都work呢
怎么样删除Localstorage呢
checkout不work -->

